<?php

require_once('C:\xampp\htdocs\webpage\connection.php');

session_start();

$email = $_POST['email'];
$password = $_POST['password'];

$fetchCount = $conn->prepare('SELECT a.userAccess_ID FROM tbl_customer_info a WHERE a.email = ? AND a.password = ?');

$fetchCount->execute([$email, $password]);
$fetchCount_ = $fetchCount->fetch();

if ($fetchCount_) {
    $_SESSION['user_ID'] = $fetchCount_['userAccess_ID'];
    $_SESSION['customerID'] = $fetchCount_['userAccess_ID']; // Set customerID in the session

    echo 'Login Successfully!';
} else {
    echo 'Login credentials do not exist. ';
}

try {
    $conn->beginTransaction();

    if (isset($_SESSION['customerID'])) {
        $customerID = $_SESSION['customerID'];

        //tbl_activity_logs
        $insertActivity = $conn->prepare('INSERT INTO tbl_activity_logs (activity, customer_ID) VALUES (?, ?)');
        $insertActivity->execute(["Logged in an account", $customerID]);
        
        $conn->commit();
    } else {
        // Handle the case where the customer is not logged in
        echo "You must be logged in to submit feedback.";
    }
} catch (\Throwable $th) {
    echo $th;
    $conn->rollBack();
}
?>
